<div id="toolbar">
    <?php echo isset($left_toolbar) ? $left_toolbar : ''; ?>
</div>