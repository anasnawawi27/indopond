<?php

return [
    'heading'               => 'Frequently Ask Questions',
    'question'                  => 'Question',
    'answer'                  => 'Answer',
    'add_heading'           => 'Add FAQ',
    'edit_heading'          => 'Edit FAQ',
];
