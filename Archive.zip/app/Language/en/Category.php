<?php

return [
    'heading'               => 'Categories',
    'name'                  => 'Name',
    'image' => 'Image',
    'add_heading'           => 'Add Category',
    'edit_heading'          => 'Edit Category',
];
