<?php

return [
    'heading'               => 'Customer',
    'logo'                  => 'Logo',
    'name'                  => 'Name',
    'add_heading'           => 'Add Customer',
    'edit_heading'          => 'Edit Customer',
];
