<?php

return [
    'label'            => 'Please Login With Your Credentials',
    'username'         => 'Username',
    'password'         => 'Password',
    'confirm_password' => 'Konfirmasi Password',
    'forgot_password'  => 'Forgot Password',
    'btn_login'        => 'Login',
];
