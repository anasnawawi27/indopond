<?php

return [
    'heading'               => 'Items',
    'add_heading'           => 'Add Item',
    'edit_heading'          => 'Edit Item',
    'name' => 'Name',
    'thumbnail' => 'Thumbnail',
    'image_slides' => 'Image Slides',
    'embed_video_youtube' => 'Youtube Video',
    'description' => 'Description',
    'with_variant' => 'Have Variant?',
    'display_price' => 'Display Price',
    'category' => 'Category'
];
