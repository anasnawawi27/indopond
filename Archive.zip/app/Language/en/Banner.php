<?php

return [
    'heading'               => 'Banners',
    'image'                 => 'Image',
    'title'               => 'Title',
    'text'                  => 'Text',
    'add_heading'           => 'Add Banner',
    'edit_heading'          => 'Edit Banner',
];
