<?php

return [
    'heading'           => 'Profile',
    'edit_heading'      => 'Edit Profile',
    'fullname'          => 'Fullname',
    'image'             => 'Profile Image',
    'email'             => 'Email',
    'phone'             => 'Phone',
    'username'          => 'Username',
    'password'          => 'Password',
    'description'       => 'Deskripsi',
];
