<?php

return [
    'heading'               => 'Payments',
    'logo'                  => 'Logo',
    'note'                  => 'Note',
    'add_heading'           => 'Add Payment',
    'edit_heading'          => 'Edit Payment',
];
