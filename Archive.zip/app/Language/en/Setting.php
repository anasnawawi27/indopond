<?php

return [
    'heading' => 'Setting',
    'company_address' => 'Address',
    'company_name' => 'Company Name',
    'email' => 'Email',
    'phone' => 'Phone',
    'shopee' => 'Shopee',
    'tokopedia' => 'Tokopedia',
    'whatsapp_1' => 'Whatsapp 1',
    'whatsapp_2' => 'Whatsapp 2',
    'whatsapp_3' => 'Whatsapp 3',
    'whatsapp_4' => 'Whatsapp 4',
    'whatsapp_main' => 'Main Whatsapp',
    'embed_map' => 'Embed Map',
    'media_facebook' => 'Facebook',
    'media_instagram' => 'Instagram',
    'media_youtube' => 'Youtube',
    'working_hour' => 'Working Hour',
    'motivational_text' => "Motivational Text",
    'about_us' => 'About Us'
];
